public class Instruction{

    private String value;
    public Instruction(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

}